"""TeamMeet transcription worker.

Speech-to-text for one speaker's audio file using faster-whisper (open source, runs locally,
no API cost). The app server calls POST /transcribe once per speaker after a recording stops.

Environment:
  RECORDINGS_DIR   folder shared with the app (default /recordings)
  WHISPER_MODEL    tiny | base | small | medium | large-v3 | distil-large-v3  (default: small)
  WHISPER_DEVICE   cpu | cuda   (default: cpu)
  WHISPER_COMPUTE  int8 (CPU) | float16 (GPU)   (default: int8)
  WHISPER_LANGUAGE e.g. "en" to force English; empty = auto-detect
"""
import os
import threading
from pathlib import Path

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from faster_whisper import WhisperModel

RECORDINGS_DIR = Path(os.getenv("RECORDINGS_DIR", "/recordings")).resolve()
MODEL_NAME = os.getenv("WHISPER_MODEL", "small")
DEVICE = os.getenv("WHISPER_DEVICE", "cpu")
COMPUTE = os.getenv("WHISPER_COMPUTE", "int8" if DEVICE == "cpu" else "float16")
LANGUAGE = os.getenv("WHISPER_LANGUAGE") or None

app = FastAPI(title="TeamMeet transcription worker")
_model = None
_lock = threading.Lock()  # one transcription at a time keeps memory predictable


def model() -> WhisperModel:
    global _model
    if _model is None:
        _model = WhisperModel(MODEL_NAME, device=DEVICE, compute_type=COMPUTE)
    return _model


class Req(BaseModel):
    path: str  # relative to RECORDINGS_DIR, e.g. "team_2026-10-12T.../audio/Amit-ab12__TR_x.ogg"


@app.get("/healthz")
def healthz():
    return {"ok": True, "model": MODEL_NAME, "device": DEVICE, "loaded": _model is not None}


@app.post("/transcribe")
def transcribe(req: Req):
    f = (RECORDINGS_DIR / req.path).resolve()
    if RECORDINGS_DIR not in f.parents or not f.is_file():
        raise HTTPException(404, f"file not found: {req.path}")
    with _lock:
        segments, info = model().transcribe(
            str(f),
            language=LANGUAGE,
            vad_filter=True,  # skip long silences (muted mics, all-day rooms)
            vad_parameters={"min_silence_duration_ms": 700},
            beam_size=5,
            condition_on_previous_text=False,  # reduces repeated/hallucinated lines
        )
        out = [{"start": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip()} for s in segments]
    return {"language": info.language, "duration": info.duration, "segments": out}
