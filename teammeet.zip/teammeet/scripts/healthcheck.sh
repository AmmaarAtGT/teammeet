#!/usr/bin/env bash
# Verifies every TeamMeet service is up. Run on the server after `docker compose up -d`.
set -uo pipefail
cd "$(dirname "$0")/.."
set -a; source .env 2>/dev/null; set +a
ok=0; bad=0
check() {
  if bash -c "$2" >/dev/null 2>&1; then echo "  ✔ $1"; ok=$((ok+1));
  else echo "  ✘ $1   → $3"; bad=$((bad+1)); fi
}

echo "TeamMeet health check"
check "Redis"                  "docker compose exec -T redis redis-cli ping | grep -q PONG"  "docker compose logs redis"
check "LiveKit server (:7880)" "curl -fsS http://localhost:7880"                             "docker compose logs livekit"
check "App server (:3000)"     "curl -fsS http://localhost:3000/healthz | grep -q ok"        "docker compose logs app"
check "Egress (recording)"     "docker compose ps --status running egress | grep -q egress"  "docker compose logs egress"
if [[ "${AI_NOTES:-on}" != "off" ]]; then
  check "Transcription worker" "curl -fsS http://localhost:8000/healthz | grep -q ok"        "docker compose logs worker"
  check "LLM endpoint + model ${LLM_MODEL:-?}" \
        "curl -fsS -H 'Authorization: Bearer ${LLM_API_KEY:-}' '${LLM_BASE_URL%/}/models' | grep -q '${LLM_MODEL:-none}'" \
        "model not pulled? docker compose exec ollama ollama pull ${LLM_MODEL:-llama3.1:8b}"
fi
check "HTTPS ${MEET_DOMAIN:-?}" "curl -fsS https://${MEET_DOMAIN:-x}/healthz | grep -q ok"   "DNS record / port 443 / docker compose logs caddy"
check "HTTPS ${RTC_DOMAIN:-?}"  "curl -fsS https://${RTC_DOMAIN:-x}"                         "DNS record / port 443 / docker compose logs caddy"
echo "$ok passed, $bad failed"
[[ $bad -eq 0 ]]
