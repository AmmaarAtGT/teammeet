#!/usr/bin/env bash
# TeamMeet one-time setup: creates .env, generates LiveKit keys, writes config files.
# Usage:  ./scripts/setup.sh meet.yourcompany.com rtc.yourcompany.com
set -euo pipefail
cd "$(dirname "$0")/.."

MEET_DOMAIN="${1:-}"; RTC_DOMAIN="${2:-}"
if [[ -z "$MEET_DOMAIN" || -z "$RTC_DOMAIN" ]]; then
  read -rp "Web app domain (e.g. meet.yourcompany.com): " MEET_DOMAIN
  read -rp "Media server domain (e.g. rtc.yourcompany.com): " RTC_DOMAIN
fi

if [[ -f .env ]]; then
  echo "• .env already exists — keeping your existing keys and settings."
  set -a; source .env; set +a
else
  LIVEKIT_API_KEY="API$(openssl rand -hex 6)"
  LIVEKIT_API_SECRET="$(openssl rand -base64 48 | tr -d '/+=\n' | cut -c1-40)"
  sed -e "s|^MEET_DOMAIN=.*|MEET_DOMAIN=${MEET_DOMAIN}|" \
      -e "s|^RTC_DOMAIN=.*|RTC_DOMAIN=${RTC_DOMAIN}|" \
      -e "s|^LIVEKIT_API_KEY=.*|LIVEKIT_API_KEY=${LIVEKIT_API_KEY}|" \
      -e "s|^LIVEKIT_API_SECRET=.*|LIVEKIT_API_SECRET=${LIVEKIT_API_SECRET}|" \
      .env.example > .env
  echo "• Created .env with new LiveKit keys."
fi

for f in livekit egress; do
  sed -e "s|__API_KEY__|${LIVEKIT_API_KEY}|g" \
      -e "s|__API_SECRET__|${LIVEKIT_API_SECRET}|g" \
      -e "s|__RTC_DOMAIN__|${RTC_DOMAIN}|g" \
      "config/${f}.yaml.template" > "config/${f}.yaml"
done
if [[ "$RTC_DOMAIN" == "localhost" ]]; then
  # Local development: no public IP discovery, no TURN (nothing to traverse on one machine)
  sed -i -e 's|use_external_ip: true.*|use_external_ip: false|' -e 's|^  enabled: true .*|  enabled: false|' config/livekit.yaml
  sed -i -e "s|^MEET_DOMAIN=.*|MEET_DOMAIN=localhost|" -e "s|^RTC_DOMAIN=.*|RTC_DOMAIN=localhost|" .env
  echo "• Local mode: external IP discovery and TURN disabled"
fi
echo "• Wrote config/livekit.yaml and config/egress.yaml"

mkdir -p recordings models
chmod 777 recordings   # egress, app and worker containers all write/read here
echo "• Prepared recordings/ and models/ folders"

cat <<MSG

Next steps:
  1. DNS: point ${MEET_DOMAIN} and ${RTC_DOMAIN} (A records) at this server's public IP.
  2. Firewall: open TCP 80, 443, 7881 and UDP 3478, 50000-60000.
  3. Start:             docker compose --profile ollama up -d --build
  4. Pull the AI model: docker compose exec ollama ollama pull ${LLM_MODEL:-llama3.1:8b}
  5. Check:             ./scripts/healthcheck.sh
  6. Open https://${MEET_DOMAIN}
MSG
