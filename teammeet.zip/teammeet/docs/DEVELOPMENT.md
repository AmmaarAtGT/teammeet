# Developer guide

## 1. Architecture

```
                     HTTPS :443 (Caddy, auto TLS)
  Browser ──────────────┬──────────────────────────────────────────┐
  (app.js +             │ meet.yourco.com                           │ rtc.yourco.com (WebSocket signalling)
   livekit-client)      ▼                                           ▼
                 ┌──────────────┐  admin API (tokens, egress)  ┌──────────────┐
                 │  app :3000   │ ───────────────────────────► │ LiveKit :7880│◄── UDP 50000-60000 / TCP 7881 / TURN 3478
                 │  Node/Express│                              │   (SFU)      │     audio + video media
                 └──────┬───────┘                              └──────┬───────┘
                        │ reads/writes                                │ jobs via Redis :6379
                        ▼                                             ▼
                 ┌─────────────────────────────┐   writes     ┌──────────────┐
                 │ ./recordings/<session>/     │ ◄─────────── │   egress     │  headless Chrome renders grid MP4;
                 │   meeting.mp4, audio/*.ogg  │              │  (recorder)  │  track egress writes per-speaker audio
                 │   transcript.json, notes.*  │              └──────────────┘
                 └──────┬──────────────────────┘
                        │ POST /transcribe (one call per speaker file)
                        ▼
                 ┌──────────────┐        ┌──────────────────────────────┐
                 │ worker :8000 │        │ LLM (Ollama :11434 or any     │◄── app: POST /v1/chat/completions
                 │ faster-whisper│       │ OpenAI-compatible endpoint)  │
                 └──────────────┘        └──────────────────────────────┘
```

Why these pieces:
- **LiveKit** is the media server (SFU). Browsers send each stream once; LiveKit forwards it to everyone. No time limits; open source.
- **app** is deliberately small: it never touches media. It issues signed join tokens, starts/stops recordings, runs the notes pipeline, and serves static files.
- **egress** is LiveKit's official recorder. One *room composite* job renders the grid video; one *track* job per microphone saves that person's raw audio.
- **worker** turns audio into timestamped text. Because each file contains **one person's microphone**, the speaker name is exact — no diarization guesswork.
- **LLM** writes the summary and action items from the merged transcript.

There is no database. State = files in `recordings/` + LiveKit's in-memory room state.

## 2. Running locally (UI and meetings only)

Requirements: Node 20+, `livekit-server` binary.

```bash
curl -sSL https://get.livekit.io | bash          # macOS: brew install livekit
livekit-server --dev                              # keys devkey/secret, ws://localhost:7880

cd app
npm install
npm run build        # bundles livekit-client, background-effects library, MediaPipe files into public/vendor
npm run dev          # http://localhost:3000, auto-restarts on server.js changes
```

Open `http://localhost:3000/test` in two windows (or one normal + one private window). Camera/mic only work on `localhost` or HTTPS.

The app's defaults (`devkey`/`secret`, `ws://localhost:7880`) match `livekit-server --dev`, so no `.env` is needed for this mode. The Record button will show an error (no egress) — that's expected.

## 3. Running the full stack locally

Needs Linux (or a Linux VM) because of host networking.

```bash
./scripts/setup.sh localhost localhost
docker compose -f docker-compose.yml -f docker-compose.local.yml --profile ollama up -d --build
docker compose exec ollama ollama pull llama3.1:8b
./scripts/healthcheck.sh      # HTTPS checks will fail locally — that's expected
```
Open `http://localhost:3000`. Recording, transcripts and AI notes all work.

Iterating on the app inside the stack: `docker compose up -d --build app` after edits; or stop the `app` container and run `npm run dev` on the host with the same env vars (`set -a; source ../.env; set +a; LIVEKIT_URL=ws://localhost:7880 RECORDINGS_DIR=../recordings npm run dev`).

## 4. File map

| File | Responsibility |
|---|---|
| `app/server.js` | Express server. Token API, passcode check, recording start/stop, per-speaker capture loop, notes pipeline (`processSession`), session/file APIs, startup recovery. |
| `app/summarize.js` | LLM client (OpenAI-compatible), prompts, map-reduce chunking, JSON parsing/cleanup. |
| `app/public/index.html` | Lobby + meeting markup. |
| `app/public/app.js` | All client logic: lobby preview, devices, joining, tile rendering, controls, chat/hand over data channel, recording buttons, screen recording, background effects. |
| `app/public/style.css` | Dark theme, grid, panels, responsive rules. |
| `app/public/notes.html` | Meeting-notes page (self-contained script). |
| `app/build/build.js` | Copies `livekit-client` UMD, bundles `@livekit/track-processors` with esbuild, copies MediaPipe WASM, downloads the segmentation model. |
| `app/tests/*.test.js` | Node built-in test runner suites. |
| `worker/main.py` | FastAPI + faster-whisper `/transcribe` endpoint. |
| `config/*` | LiveKit, egress, Caddy configs. |
| `scripts/*` | Setup and health checks. |

## 5. How each feature works

### Joining
1. Lobby calls `GET /api/config` (LiveKit URL, whether passcode is needed).
2. `POST /api/token {name, room}` → server sanitizes the room name (`[a-z0-9-_]`), creates a unique identity `Name-xxxxxx`, signs a JWT (24h TTL, publish/subscribe/data grants).
3. Browser `room.connect(url, token)`, then enables mic/camera according to the lobby toggles.
4. Room URL becomes `/<room>`; any `/<room>` path serves `index.html` and pre-fills the room.

**No time limit:** LiveKit has none; tokens last 24h and are only validated on connect/reconnect.

### Tiles, speaking indicator, quality
`render()` rebuilds tiles from LiveKit participant state on every relevant `RoomEvent` (idempotent, keyed by `identity:cam` / `identity:screen`). Screen shares get their own tile and take the large "focus" position; any tile can be pinned. `ActiveSpeakersChanged` sets the green border/name tag and the top-bar "🎙 name". `ConnectionQualityChanged` colours the dot (green / amber / red).

### Mute, camera, screen share
`setMicrophoneEnabled`, `setCameraEnabled`, `setScreenShareEnabled` on the local participant. Muting keeps the track published (fast unmute); others see 🔇 / avatar via `TrackMuted` events.

### Chat and raise hand
JSON messages over LiveKit's reliable data channel, topic `teammeet`: `{type:'chat', text}`, `{type:'hand', up}`, `{type:'rec', on}`. Chat is not stored on the server (ephemeral, like Meet's in-call chat). People who join later don't see earlier messages.

### Background blur / color (per person)
- Library: `@livekit/track-processors` (MediaPipe selfie segmentation in WebGL), bundled to `public/vendor/track-processors.js`.
- `applyBackground(track)` attaches a `BackgroundProcessor` in `background-blur` mode (radius 6/14/28) or `virtual-background` mode using a solid-colour image generated on a canvas.
- The processor runs **in the sender's browser**, so everyone (and the recording) sees the processed video. The choice is saved in `localStorage` (`tm_bg`) and re-applied on every join and when the camera is re-published.
- MediaPipe WASM and the model are served from `/vendor/mediapipe/` (self-hosted). If the model file is missing, the code falls back to Google's CDN.
- Unsupported browsers (some mobile Safari versions) show a message instead.

### Server meeting recording + AI notes
```
Record clicked ─► POST /api/recording/start
   startSession(): mkdir recordings/<id>/audio
                   startRoomCompositeEgress → <id>/meeting.mp4 (grid layout)
                   captureNewSpeakers(): startTrackEgress per microphone → <id>/audio/<identity>__<trackSid>.ogg
                   poll every 5s for new/rejoined speakers
Stop clicked ──► POST /api/recording/stop
   stopSession(): stop all egress jobs, status=processing
   processSession():
     1. wait until every egress job is COMPLETE/FAILED (gives up after 2 min if egress is unreachable)
     2. offset of each audio file = its egress start − meeting start
     3. status=transcribing: worker /transcribe per file (VAD skips silence)
     4. merge all segments, sort by time → transcript.json [{speaker,start,end,text}]
     5. status=summarizing: summarize() → notes.json + notes.md
     6. status=ready (or error + message)
```
`session.json` is written at every step, so the notes page shows live progress. On server restart, sessions stuck in processing states are resumed automatically; a session that was *recording* during a restart is closed and processed with whatever was captured.

### Summaries (`summarize.js`)
- Transcript is formatted `[mm:ss] Speaker: text`.
- If longer than `LLM_CHUNK_CHARS`: each chunk → free-text notes (map), then all notes → final JSON (reduce). Otherwise a single call.
- The final call requests JSON (`response_format: json_object`); the parser also accepts JSON wrapped in prose/code fences. Owners with no items are dropped.
- Prompts forbid inventing tasks/owners/dates. Edit `SYSTEM` and `FINAL_SCHEMA` to change the output (e.g. add "risks" or "next meeting agenda"); update `notesToMarkdown()` in `server.js` and `notes.html` to display new fields.

### Local screen recording
Runs entirely in the browser: `getDisplayMedia` (screen/window/tab + its audio) + Web Audio mix of your mic and every remote mic → `MediaRecorder` (WebM VP9/VP8, MP4 on Safari) → file download when stopped. Stopping via the browser's "Stop sharing" bar also finishes the file. No server involvement, so it works even without egress.

## 6. HTTP API

All endpoints except `/api/config`, `/healthz` and the HTML pages require the passcode (when set) via header `x-team-passcode` (or `?p=`).

| Method & path | Body / query | Response |
|---|---|---|
| `GET /api/config` | — | `{livekitUrl, passcodeRequired, aiNotes}` |
| `POST /api/token` | `{name, room}` | `{token, url, room, identity}` · 400 missing fields · 401 passcode |
| `GET /api/recording/status?room=` | — | `{recording, sessionId, since}` |
| `POST /api/recording/start` | `{room, name}` | `{sessionId}` · 500 if egress unavailable |
| `POST /api/recording/stop` | `{room}` | `{ok, sessionId}` |
| `GET /api/sessions?room=` | room optional | `[{id, room, status, createdAt, stoppedAt, participants, error}]` newest first |
| `GET /api/sessions/:id` | — | `{session, transcript, notes}` |
| `POST /api/sessions/:id/reprocess` | — | re-runs transcription + summary · 409 if busy |
| `GET /files/:id/:file` | `?download=1` | `meeting.mp4`, `notes.md`, `notes.json`, `transcript.json` only |
| `GET /notes/:id` | — | notes page |
| `GET /:room` | — | meeting app |
| `GET /healthz` | — | `ok` |

Worker: `POST /transcribe {path}` (relative to recordings dir) → `{language, duration, segments:[{start,end,text}]}`; `GET /healthz`.

Session `status` values: `recording → processing → transcribing → summarizing → ready | error`.

## 7. Data formats

`recordings/<room>_<ISO-timestamp>/`
```
session.json      {id, room, status, startedBy, createdAt, stoppedAt, compositeEgressId,
                   tracks:[{trackSid, identity, name, file, egressId, startedAtMs, offsetSec}],
                   participants:[names], hasVideo, error?}
meeting.mp4       grid recording
audio/*.ogg       one Opus file per microphone track (a person who rejoins gets a second file)
transcript.json   [{speaker, start, end, text}]   seconds from meeting start
notes.json        {summary, decisions[], action_items:[{owner, items:[{task, due, context}]}],
                   topics:[{title, notes}], open_questions[], model, generatedAt}
notes.md          human-readable version of notes.json
```

## 8. Extending — common requests

| Want | Where to change |
|---|---|
| Post notes to Slack/email automatically | End of `processSession()` in `server.js`, after `status: 'ready'` — call a webhook with `notes.md`. |
| Store recordings in S3 / Google Drive | Use egress `S3Upload` output in `startSession()` / `captureNewSpeakers()`, or upload the folder after `ready`. |
| Per-person logins instead of a shared passcode | Replace `checkPasscode()` with your SSO/OAuth check; put the verified name into the token. |
| Persistent chat history | Store `chat` messages server-side (e.g. send them to a new `/api/chat` endpoint) and load on join. |
| Live captions during the meeting | Add a LiveKit Agent (Python/Node) that subscribes to audio and publishes transcriptions; out of scope for v1. |
| Different recording layout | `layout: 'speaker'` in `startSession()`. |
| Breakout rooms | They're just different room names — add a UI that links to `/<room>-breakout-1`. |
| Waiting room / host controls (mute others, remove) | Use `RoomServiceClient.mutePublishedTrack` / `removeParticipant` in new admin endpoints; gate with an admin passcode. |

## 9. Conventions

- No front-end framework or build step for app code — plain JS so any developer can change it. Only third-party browser libraries are bundled (`npm run build`).
- `public/vendor/` is generated; don't edit by hand.
- Keep server endpoints validating/sanitising input (`cleanRoom`, `safeId`, file whitelist) — see the tests for expected behaviour.
- Run `npm test` before every commit.
