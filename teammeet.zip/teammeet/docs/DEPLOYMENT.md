# Deployment guide

Follow the steps in order. Each step ends with a check so you know it worked before moving on.

## 1. Server sizing

TeamMeet is an SFU (selective forwarding unit): video is forwarded, not re-encoded, so CPU stays low; **bandwidth is the main limit**. "Unlimited participants" means the software imposes no cap (`max_participants: 0`); the practical limit is your server.

| Team / usage | Server | Notes |
|---|---|---|
| Up to ~25 people, recording + AI notes on CPU | **8 vCPU, 16 GB RAM**, 1 Gbps, 100 GB disk | Recommended starting point |
| Up to ~50 people in one room | 8–16 vCPU, 16–32 GB RAM, 1 Gbps+ | Encourage camera-off for non-speakers in very large rooms |
| Faster AI notes | Add an NVIDIA GPU (≥8 GB VRAM) | Whisper + Ollama run 10–20× faster |
| 100+ simultaneous people | Multiple LiveKit nodes sharing Redis | See §10 Scaling |

Rough budget per person: ~1.5–2.5 Mbps upload from each camera; each viewer downloads the streams they see (adaptive stream picks lower resolutions for small tiles). Each active server recording runs a headless Chrome: ~2 vCPU + 2 GB RAM while recording.

Disk: a 1-hour grid MP4 is roughly 300–700 MB; per-speaker audio is ~15–30 MB/hour each.

Any Linux VPS works (Hetzner, DigitalOcean, AWS EC2, OVH…). **Host networking requires Linux** — Docker Desktop on macOS/Windows is for development only.

## 2. DNS

Create two A-records pointing to the server's public IPv4:

| Name | Purpose |
|---|---|
| `meet.yourco.com` | Web app people open |
| `rtc.yourco.com` | Media server (browsers connect via secure WebSocket) |

Check: `dig +short meet.yourco.com` and `dig +short rtc.yourco.com` both print the server IP.

## 3. Firewall

Open these **inbound** ports (cloud security group *and* host firewall such as `ufw`):

| Port | Protocol | Used by |
|---|---|---|
| 80 | TCP | Let's Encrypt certificate issuance (Caddy) |
| 443 | TCP | HTTPS for both domains |
| 7881 | TCP | WebRTC over TCP (fallback when UDP is blocked) |
| 3478 | UDP | TURN (people behind strict NAT) |
| 50000–60000 | UDP | WebRTC media |

```bash
sudo ufw allow 80,443,7881/tcp
sudo ufw allow 3478/udp
sudo ufw allow 50000:60000/udp
```

Ports 3000 (app), 7880 (LiveKit API), 6379 (Redis), 8000 (worker) and 11434 (Ollama) stay **closed** to the internet; they are reached through Caddy or only on localhost.

## 4. Install Docker

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER   # log out and back in
docker compose version          # must print v2.x
```

## 5. Get the code and configure

```bash
git clone <your-repo-url> teammeet && cd teammeet
./scripts/setup.sh meet.yourco.com rtc.yourco.com
```

This:
- creates `.env` with a **freshly generated** LiveKit API key and secret,
- writes `config/livekit.yaml` and `config/egress.yaml` with the same keys,
- prepares `recordings/` (world-writable, because three containers share it) and `models/`.

Then edit `.env` as needed (see [CONFIGURATION.md](CONFIGURATION.md)). At minimum consider:
- `TEAM_PASSCODE=` — set a passcode if room links may leak.
- `WHISPER_LANGUAGE=en` — or empty to auto-detect per speaker.

> If you change `LIVEKIT_API_KEY`/`LIVEKIT_API_SECRET` by hand, delete `config/livekit.yaml` and `config/egress.yaml` and re-run `setup.sh` so all three files match.

## 6. Start

**Option A — fully self-hosted AI (free, private):**

```bash
docker compose --profile ollama up -d --build
docker compose exec ollama ollama pull llama3.1:8b
```

**Option B — hosted LLM** (better summaries, small per-meeting cost): set in `.env`

```
LLM_BASE_URL=https://api.openai.com/v1
LLM_API_KEY=sk-...
LLM_MODEL=gpt-4o-mini
```
then `docker compose up -d --build` (no `--profile ollama`). Any OpenAI-compatible provider works the same way. Transcription still runs locally.

**Option C — no AI notes:** set `AI_NOTES=off`; you can also skip the worker: `docker compose up -d --build redis livekit egress app caddy`.

The first start downloads images and builds the app (~3–6 minutes). The Whisper model downloads on the first transcription into `models/`.

## 7. Verify

```bash
./scripts/healthcheck.sh
```

Expected: every line ✔. If something fails, the line tells you which log to read; see [TROUBLESHOOTING.md](TROUBLESHOOTING.md).

Then run the 5-minute smoke test in [TESTING.md §4](TESTING.md#4-production-smoke-test-5-minutes).

## 8. Daily operation

| Task | Command |
|---|---|
| See status | `docker compose ps` |
| Follow logs | `docker compose logs -f app` (or `livekit`, `egress`, `worker`, `caddy`, `ollama`) |
| Restart one service | `docker compose restart app` |
| Stop everything | `docker compose down` |
| Disk used by recordings | `du -sh recordings/` |
| Delete recordings older than 90 days | `find recordings -mindepth 1 -maxdepth 1 -type d -mtime +90 -exec rm -rf {} +` |

Put the cleanup line in `crontab -e` if you want automatic retention.

## 9. Upgrades and backups

**Upgrade the app:**
```bash
git pull
docker compose up -d --build app worker
```

**Upgrade LiveKit/egress:** the compose file uses `:latest`. Once you are happy, pin exact versions (e.g. `livekit/livekit-server:v1.9.1`) so upgrades are deliberate:
```bash
docker compose pull livekit egress && docker compose up -d livekit egress
```
Upgrade outside working hours — restarting LiveKit disconnects everyone for a few seconds (clients reconnect automatically).

**Back up:** `.env`, `config/livekit.yaml`, `config/egress.yaml`, and `recordings/`. Nothing else holds state (no database).

## 10. Scaling beyond one server

- **More people per room:** vertical scale (more bandwidth/CPU) first. LiveKit also supports multi-node clusters: run more `livekit` nodes pointing at the **same Redis**, behind a load balancer for `rtc.yourco.com`. See LiveKit's "distributed setup" docs.
- **More simultaneous recordings:** run more `egress` containers (same config) on other machines pointing at the same Redis; each picks up jobs automatically. Mount shared storage (NFS) at `./recordings` or switch egress output to S3 (see LiveKit egress docs) and adjust `server.js`.
- **Faster AI notes:** GPU worker (uncomment the `deploy:` block in `docker-compose.yml`, set `WHISPER_DEVICE=cuda`, `WHISPER_COMPUTE=float16`, install the NVIDIA Container Toolkit).

## 11. Security checklist

- [ ] `TEAM_PASSCODE` set (anyone with the link can otherwise join)
- [ ] `.env` readable only by the admin (`chmod 600 .env`)
- [ ] Only ports in §3 are open
- [ ] Automatic OS security updates enabled (`unattended-upgrades`)
- [ ] Recordings retention policy decided (§8)
- [ ] Team informed that meetings may be recorded and transcribed. Recording-consent laws vary by state and country (some require everyone's consent) — the REC badge is visible to all, but announce it too.
