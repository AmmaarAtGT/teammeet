# Testing guide

Four layers, from fastest to most realistic. Run 1–3 before every release; run 4 after every deployment.

## 1. Automated unit/API tests (10 seconds, no services needed)

```bash
cd app
npm install
npm test
```

11 tests covering:
- config endpoint; passcode enforcement; input validation
- join token contents: room grant, publish rights, **≥23h lifetime** (no 90-minute limit)
- recording start fails cleanly when the recorder is down
- sessions listing, file whitelist, path-traversal protection
- room links and notes page routing
- AI notes: speaker-labelled prompt format, single-call vs chunked (map-reduce) summaries, empty-transcript handling, cleanup of empty owners — against a fake LLM

Expected output ends with `# pass 11` / `# fail 0`.

## 2. Pipeline test (20 seconds, no LiveKit/Whisper/LLM needed)

```bash
cd app
bash tests/e2e/pipeline_e2e.sh
```
Fakes a finished two-speaker recording, stubs the transcription worker and the LLM, and checks the app produces a time-ordered transcript with exact speaker names, per-person action items and `notes.md`. Expected: `PIPELINE CHECKS PASSED`.

## 3. Browser end-to-end test (1 minute)

```bash
pip install playwright && python -m playwright install chromium
livekit-server --dev                      # terminal 1
cd app && npm run dev                     # terminal 2
python tests/e2e/meeting_e2e.py           # terminal 3 (from app/)
```
Two headless browsers with fake cameras join the same room and verify: both videos play, mute/camera-off propagate, chat delivers, raise hand shows, background panel works, recordings tab loads, leaving updates the other side. Expected: `ALL MEETING CHECKS PASSED`. A screenshot is saved as `e2e-meeting.png`.

Point it at a deployment with `TEAMMEET_URL=https://meet.yourco.com python tests/e2e/meeting_e2e.py` (if a passcode is set, test manually instead or extend the script to fill `#passInput`).

## 4. Production smoke test (5 minutes, real devices)

Do this after every deployment. Use **two different devices on different networks** (e.g. laptop on office Wi-Fi + phone on mobile data) — this is what catches firewall/TURN problems.

1. `./scripts/healthcheck.sh` → all ✔.
2. Device A: open `https://meet.yourco.com/smoke`, join as "Tester A". Lobby preview shows your camera.
3. Device B: open the same link, join as "Tester B".
4. Both see two tiles with live video; speaking on one shows the green border on the other.
5. Record → wait 1 minute while both talk (each say one clear task, e.g. "B will send the report tomorrow") → Stop.
6. Chat → Recordings tab → open the new entry. Status moves Finishing files → Transcribing → Writing notes → Ready (a few minutes on CPU).
7. Notes page: video plays; transcript shows both names correctly; action items list "Tester B — send the report, due tomorrow".

If 4 fails only across networks → firewall/UDP ports (see TROUBLESHOOTING). If 6 sticks → worker/LLM logs.

## 5. Full manual QA checklist

Use for release sign-off. Browsers: Chrome, Edge, Firefox, Safari (macOS), Chrome Android, Safari iOS.

### Lobby
- [ ] Camera preview appears; mic/camera dropdowns list devices
- [ ] Mic toggle and camera toggle in the preview work (camera off shows "Camera is off")
- [ ] Background button opens panel; blur and colors apply to the preview
- [ ] Name and room are remembered after reload
- [ ] Opening `/<room>` pre-fills the room
- [ ] With `TEAM_PASSCODE` set: field shown; wrong passcode → "Wrong team passcode"; right → joins
- [ ] Denying camera permission shows a clear message and still allows joining

### In meeting
- [ ] Mic button mutes/unmutes; others see 🔇; Ctrl/⌘+D works
- [ ] Camera button turns video off/on; others see avatar initials; Ctrl/⌘+E works
- [ ] Share: pick a tab with audio → becomes the large tile for everyone; tab audio heard; "Stop share" and the browser's "Stop sharing" both end it
- [ ] Pin any tile → it becomes large; Unpin restores the grid
- [ ] Speaking indicator: green border + green name + "🎙 name" in top bar
- [ ] Network dot turns amber/red when throttled (Chrome DevTools → Network → Slow 3G)
- [ ] Raise hand shows ✋ on your tile for everyone + toast; click again lowers it
- [ ] Chat: messages arrive for all; unread red dot when panel closed
- [ ] People tab lists everyone with mic/camera/hand state
- [ ] Copy invite link copies `https://…/<room>`
- [ ] Participant count badge is correct
- [ ] Background: blur levels and colors apply to *your* tile for others; choice persists after rejoin; "None" removes it
- [ ] Leave returns to lobby; others see you leave
- [ ] Close the laptop lid / toggle Wi-Fi for 10s → "Reconnecting…" then "Reconnected"
- [ ] **Long-duration test:** stay in a room for 3+ hours — no disconnect (Jitsi's limit was 90 min)

### Server recording + AI notes
- [ ] Record → red REC badge visible to **everyone**; chat shows "X started recording"
- [ ] Someone joins mid-recording → they appear in the transcript
- [ ] Someone leaves and rejoins mid-recording → both parts appear under the same name
- [ ] Stop → confirmation; files appear in Recordings tab with live status
- [ ] Notes page: video plays; click a transcript line → video jumps there; current line highlights while playing; search filters lines
- [ ] Summary, action items by person (with due dates when said), decisions, detailed notes, open questions are sensible
- [ ] Download video, Download notes (.md), Copy notes work
- [ ] Regenerate AI notes works (e.g. after changing `LLM_MODEL`)
- [ ] Muted-all-meeting participant does not produce garbage text

### Local screen recording
- [ ] Screen rec → pick screen/window/tab → amber "Screen rec" badge
- [ ] Stop → `.webm` (Safari: `.mp4`) downloads; contains video + your voice + others' voices
- [ ] Clicking the browser's "Stop sharing" also saves the file
- [ ] Leaving the page while recording asks for confirmation

### Mobile
- [ ] Phone joins; controls show icons only; side panel goes full-screen
- [ ] Rotating the phone re-flows the grid

## 6. Load testing

LiveKit ships a load tester that simulates publishers/subscribers:

```bash
# install the CLI: https://github.com/livekit/livekit-cli
lk load-test --url wss://rtc.yourco.com --api-key <KEY> --api-secret <SECRET> \
  --room load-test --video-publishers 10 --subscribers 40 --duration 5m
```
Watch `docker stats` and the server's network throughput during the run. Increase until CPU > 70% or bandwidth nears the NIC limit — that's your practical room size.

## 7. Transcription accuracy check

Record a 2-minute meeting reading a known script. Compare `transcript.json` to the script. If accuracy is poor:
- set `WHISPER_LANGUAGE` explicitly,
- use a bigger `WHISPER_MODEL` (`medium` or `large-v3`, ideally on GPU),
- ask people to use headsets (removes echo/bleed between speakers).
