# User guide

## Joining

1. Open the team link, e.g. `https://meet.yourco.com/team` (each word after the `/` is a separate room — `/standup`, `/sales`, …).
2. Allow camera and microphone when the browser asks.
3. Check your preview. Use the three round buttons to toggle **mic**, **camera**, and **background** before joining.
4. Enter your name (shown to everyone and used in the AI notes — use your real name), and the team passcode if asked.
5. **Join meeting.**

The room has **no time limit**. Stay all day; it stays open as long as anyone is in it.

## Bottom bar

| Button | What it does |
|---|---|
| **Mic** | Mute / unmute yourself. Red = muted. Shortcut **Ctrl+D** (Mac **⌘+D**). |
| **Camera** | Turn your video off / on. Red = off; others see your initials. Shortcut **Ctrl+E** (⌘+E). |
| **Share** | Share your screen, a window, or a browser tab. Tick "Share tab audio" to share a video's sound. It appears large for everyone. Click again (**Stop share**) to stop. |
| **Background** | Blur your background (light / medium / strong) or replace it with a neutral color (8 presets or any custom color). Only affects **your** video; remembered on this device. Choose **None** to turn off. |
| **Record** | Records the **whole meeting on the server** (video + everyone's audio) and then creates the transcript and AI notes. Everyone sees a red **● REC** badge. Click again (**Stop rec**) to stop for everyone. |
| **Screen rec** | Records **your screen** plus everyone's audio **to your own computer**. When you stop, a video file downloads. Nobody else is notified, so tell people you're recording. |
| **Hand** | Raise / lower your hand. Everyone sees ✋ on your tile and a pop-up. |
| **Chat** | Opens the side panel: **Chat** (messages to everyone in the room), **People** (who's here, mic/camera/hand state), **Recordings** (past recordings and AI notes for this room). A red dot means unread messages. |
| **Leave** | Leave the meeting. |

## Top bar

- Room name and how long you've been in the meeting.
- **🎙 Name** — who is speaking right now. Their tile also gets a green border and green name tag.
- **● REC** — the meeting is being recorded on the server. **● Screen rec** — you are recording your screen locally.
- **Copy invite link** — copies the room link to send to someone.
- 👥 — number of people in the room.

## Video tiles

- Hover a tile → **Pin** to make it large (click **Unpin** to go back).
- A screen share automatically becomes the large tile.
- The small dot next to a name shows network quality: green good, amber poor, red lost.
- 🔇 means that person is muted. ✋ means their hand is raised.

## Meeting notes

After a recording stops, open **Chat → Recordings** and click the meeting. The notes page shows progress, then:

- **Summary** of the meeting
- **Action items by person**, with due dates when someone said one — tick them off as you go
- **Decisions**, **Detailed notes** per topic, **Open questions**
- **Transcript** with each speaker's name. Click any line to jump the video to that moment. Use the search box to find a word.
- **Download video**, **Download notes (.md)**, **Copy notes** (paste into Slack/email/docs)

Notes take a few minutes after a meeting (longer for long meetings). The page refreshes on its own.

Tips for great notes: use your real name when joining; say tasks clearly ("Ammar will finish the README by Friday"); use a headset if you can.

## Etiquette

- Announce when you start recording. Some places require everyone's consent.
- Mute when not speaking in big rooms.
- Turn off the camera if your connection is poor — audio stays smooth.

## Supported browsers

Chrome, Edge, Firefox, and Safari on desktop; Chrome on Android; Safari on iPhone/iPad. Background effects and screen recording work best in desktop Chrome or Edge. Screen sharing is not available on most phones.
