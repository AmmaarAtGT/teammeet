# Troubleshooting

Start with `./scripts/healthcheck.sh` — each failed line names the log to read. Logs: `docker compose logs --tail=200 <service>`.

## Joining and media

| Symptom | Likely cause | Fix |
|---|---|---|
| "Camera/mic blocked" in lobby | Browser permission denied, or page not on HTTPS | Click the camera icon in the address bar → Allow. Only `https://` and `http://localhost` can use cameras. |
| Join spins then errors "could not establish signal connection" | Browser can't reach `wss://RTC_DOMAIN` | `curl https://rtc.yourco.com` should return `OK`. Check DNS, port 443, `docker compose logs caddy livekit`. Make sure `.env` `RTC_DOMAIN` is correct and the app was restarted. |
| Join works but no video/audio from others ("could not establish pc connection") | UDP media ports blocked | Open UDP 50000–60000, TCP 7881, UDP 3478 in **both** the cloud firewall and `ufw`. Check `use_external_ip: true` in `config/livekit.yaml`. |
| Works on office Wi-Fi, fails on some corporate/hotel networks | Only port 443 allowed outbound | Set up TURN over TLS (CONFIGURATION.md §2). |
| "Wrong team passcode" | Passcode changed or typo | Check `TEAM_PASSCODE` in `.env`. Browsers remember the last passcode — re-type it in the lobby. |
| Can't hear anyone | Browser autoplay block | Click anywhere on the page (a toast says so). |
| Echo / feedback | Speakers + open mic | Use headphones; echo cancellation is on by default. |
| Video freezes / pixelated | Weak network (amber/red dot) | Turn camera off; adaptive streaming lowers quality automatically. Check server bandwidth with `docker stats` / `iftop`. |
| `401 invalid token` in LiveKit logs | Keys mismatch | `.env` keys must equal those in `config/livekit.yaml` and `config/egress.yaml`. Re-run `scripts/setup.sh` after deleting the two yaml files, then `docker compose up -d`. |

## Background effects

| Symptom | Fix |
|---|---|
| "Background effects are not supported in this browser" | Use desktop Chrome, Edge or Firefox. Some mobile browsers lack the required APIs. |
| "Could not apply background…" | Rebuild the app (`docker compose up -d --build app`) so the MediaPipe model is downloaded into `public/vendor/mediapipe/`. If the server can't reach `storage.googleapis.com` at build time, browsers fetch the model from Google's CDN — make sure clients can reach it, or copy `selfie_segmenter.tflite` into that folder manually. |
| Laptop fan spins / video lags with blur | Effect runs on your computer's GPU. Use "Light blur" or a color, or turn it off. |

## Recording

| Symptom | Likely cause | Fix |
|---|---|---|
| "Could not start recording… Is the egress service running?" | Egress down or not connected to Redis | `docker compose ps egress`, `docker compose logs egress`. Egress needs `cap_add: SYS_ADMIN` and the same keys and Redis as LiveKit. |
| Recording stops immediately / `meeting.mp4` missing | Egress can't write to `recordings/` | `chmod 777 recordings` (setup.sh does this). Check free disk: `df -h`. |
| Grid video is black | Egress's headless Chrome can't load the layout template | It loads LiveKit's hosted template; the server needs outbound HTTPS. Check `docker compose logs egress` for template errors. |
| Recording ended when the app restarted | Recording state is kept in memory | On startup the app stops those recorder jobs and processes what was captured. Start a new recording if needed. |

## AI notes

| Status stuck at | Cause | Fix |
|---|---|---|
| Finishing files | Egress still writing, or unreachable | Waits up to 2 min if egress is unreachable, then continues with whatever files exist. Check `docker compose logs egress`. |
| Transcribing (long time) | Normal on CPU for long meetings, or first-time model download | `docker compose logs -f worker`. First run downloads the Whisper model (hundreds of MB). Use a smaller `WHISPER_MODEL` or a GPU. |
| Error: "Transcription worker error" | Worker down / out of memory | `docker compose logs worker`; `free -h`. `medium`/`large-v3` on CPU need several GB RAM. |
| Error: "LLM 404 … model not found" | Model not pulled | `docker compose exec ollama ollama pull llama3.1:8b` (or whatever `LLM_MODEL` says). |
| Error: "LLM did not return valid JSON" | Small model struggled | Click **Regenerate AI notes**; or use a stronger model (`qwen2.5:14b`, or a hosted model). |
| Error: "fetch failed" / timeout | LLM endpoint unreachable or too slow | Check `LLM_BASE_URL`; raise `LLM_TIMEOUT_MS`; lower `LLM_CHUNK_CHARS`. |
| Wrong names in transcript | People joined with nicknames | Names come from the lobby name field — ask everyone to use real names. |
| Someone missing from transcript | They were muted the whole time, or joined < 5 s before stop | Expected. |
| Garbled words / wrong language | Auto-detect picked wrong language | Set `WHISPER_LANGUAGE`; use a bigger model; headsets reduce cross-talk. |

After fixing any AI-notes problem, open the meeting's notes page and click **Regenerate AI notes**.

## Local screen recording

| Symptom | Fix |
|---|---|
| "This browser cannot record the screen" | Use desktop Chrome, Edge or Firefox. |
| Downloaded file has no other people's audio | Others' audio is mixed in from the meeting — make sure they were unmuted and you were connected. If you shared a tab, also tick "Share tab audio". |
| `.webm` won't open | Play it in Chrome/VLC, or convert: `ffmpeg -i in.webm out.mp4`. |

## HTTPS / certificates

| Symptom | Fix |
|---|---|
| Browser certificate warning | Caddy couldn't get a certificate: ports 80/443 must be open and DNS must point to the server **before** first start. `docker compose logs caddy`, then `docker compose restart caddy`. |
| Rate-limited by Let's Encrypt | Too many failed attempts; wait an hour, fix DNS/ports first. |
