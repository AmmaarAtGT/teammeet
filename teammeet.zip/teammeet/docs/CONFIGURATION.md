# Configuration reference

All settings live in `.env` (created from `.env.example` by `scripts/setup.sh`). After changing `.env`, apply with:

```bash
docker compose up -d          # recreates only the services whose settings changed
```

## 1. Environment variables (`.env`)

### Domains and keys

| Variable | Default | Used by | Description |
|---|---|---|---|
| `MEET_DOMAIN` | — | caddy | Hostname of the web app. Caddy gets an HTTPS certificate for it. |
| `RTC_DOMAIN` | — | caddy, app | Hostname of the media server. The app tells browsers to connect to `wss://RTC_DOMAIN`. |
| `LIVEKIT_API_KEY` | generated | app | Must match the key in `config/livekit.yaml` and `config/egress.yaml`. |
| `LIVEKIT_API_SECRET` | generated | app | Signs join tokens. ≥32 characters. Keep secret. |

### Access

| Variable | Default | Description |
|---|---|---|
| `TEAM_PASSCODE` | empty | If set, the lobby asks for it and every API call requires it (header `x-team-passcode`, or `?p=` for file downloads). Empty = anyone with the link can join. Browsers remember it after the first join. |

### AI notes

| Variable | Default | Description |
|---|---|---|
| `AI_NOTES` | `on` | `off` = recordings produce only the video; no per-speaker audio, transcript or summary. |
| `WHISPER_MODEL` | `small` | Speech-to-text model. Accuracy vs speed: `tiny` < `base` < `small` < `medium` < `large-v3`. `distil-large-v3` is near-large accuracy at ~2× speed (English only). On CPU, `small` is the sweet spot; with a GPU use `large-v3`. |
| `WHISPER_DEVICE` | `cpu` | `cuda` for NVIDIA GPU (needs the compose `deploy:` block + NVIDIA Container Toolkit). |
| `WHISPER_COMPUTE` | `int8` | `int8` on CPU; `float16` on GPU. |
| `WHISPER_LANGUAGE` | `en` | ISO code to force a language (faster, fewer mistakes). Empty = auto-detect per speaker file. |
| `LLM_BASE_URL` | `http://localhost:11434/v1` | Any OpenAI-compatible endpoint. Default is the bundled Ollama. |
| `LLM_API_KEY` | `ollama` | API key for the endpoint (Ollama ignores it). |
| `LLM_MODEL` | `llama3.1:8b` | Model name at that endpoint. Bigger = better notes. Good local options: `llama3.1:8b`, `qwen2.5:14b`, `mistral-nemo`. Hosted: `gpt-4o-mini`, etc. |
| `LLM_CHUNK_CHARS` | `24000` | Transcript size per LLM call. Long meetings are split into chunks, each summarized, then combined. Lower to `8000` for models with small context windows. |

### App-internal (set in `docker-compose.yml`, rarely changed)

| Variable | Compose value | Description |
|---|---|---|
| `PORT` | `3000` | App HTTP port (Caddy proxies to it). |
| `LIVEKIT_URL` | `wss://${RTC_DOMAIN}` | URL handed to browsers. |
| `LIVEKIT_HOST` | `http://localhost:7880` | URL the app uses for LiveKit admin APIs. |
| `RECORDINGS_DIR` | `/recordings` | Where the app reads/writes session folders. |
| `EGRESS_OUTPUT_DIR` | `/out` | The **same** folder as seen inside the egress container. Both map to `./recordings` on the host. |
| `WORKER_URL` | `http://localhost:8000` | Transcription worker. |
| `TOKEN_TTL` | `24h` (code default) | Join-token lifetime. Tokens are only checked when joining/reconnecting, so this bounds how long someone can stay without rejoining. |
| `LLM_TIMEOUT_MS` | `600000` (code default) | Per LLM call timeout. |

## 2. `config/livekit.yaml` (media server)

Generated from `livekit.yaml.template`. Key settings:

| Setting | Value | Meaning |
|---|---|---|
| `port` | 7880 | HTTP/WebSocket signalling (behind Caddy). |
| `rtc.tcp_port` | 7881 | ICE over TCP fallback. |
| `rtc.port_range_start/end` | 50000–60000 | UDP media ports. Narrowing is fine (≥ 2 ports per participant). |
| `rtc.use_external_ip` | true | Discover the public IP via STUN (required on cloud VMs behind 1:1 NAT). |
| `room.empty_timeout` | 300 | Seconds an empty room stays alive. |
| `room.max_participants` | 0 | 0 = no limit. |
| `turn.enabled` / `udp_port` | true / 3478 | Embedded TURN relay for people on restrictive networks. |
| `keys` | generated | `KEY: SECRET` pair; must match `.env`. |

Restart after edits: `docker compose restart livekit`.

**Optional — TURN over TLS (443)** for very locked-down corporate networks: add a third DNS name (e.g. `turn.yourco.com`), give LiveKit a certificate for it, and set `turn.tls_port: 5349` with `turn.cert_file`/`key_file` (see LiveKit's TURN docs). Most teams don't need this; TCP 7881 + UDP 3478 cover the usual cases.

## 3. `config/egress.yaml` (recorder)

| Setting | Meaning |
|---|---|
| `api_key` / `api_secret` | Same pair as LiveKit. |
| `ws_url` | `ws://localhost:7880` — egress joins the room like a hidden participant. |
| `redis.address` | Job queue shared with LiveKit. |

The grid recording is rendered by LiveKit's default web template (headless Chrome inside egress). The layout is set in `server.js` (`layout: 'grid'`); other built-in layouts: `speaker`, `single-speaker`.

## 4. `config/Caddyfile`

Reverse proxy with automatic Let's Encrypt certificates. Reads `MEET_DOMAIN` and `RTC_DOMAIN` from the environment. To use your own certificates, add `tls /path/cert.pem /path/key.pem` inside each site block and mount the files.

## 5. Client-side defaults (in `app/public/app.js`)

| What | Where | Default |
|---|---|---|
| Camera resolution | `videoCaptureDefaults` | 720p |
| Simulcast / codec | `publishDefaults` | on / VP8 |
| Adaptive stream & dynacast | `new Room({...})` | on (saves bandwidth in big rooms) |
| Echo cancellation, noise suppression, auto gain | `audioCaptureDefaults` | on |
| Grid columns | `layoutGrid()` | up to 5 desktop / 3 tablet / 2 phone |
| Background presets | `BG_EFFECTS`, `BG_COLORS` | 3 blur strengths, 8 neutral colors |
| Screen-recording bitrate | `startLocalRecording()` | 2.5 Mbps |
| Shortcuts | `keydown` handler | Ctrl/⌘+D mic, Ctrl/⌘+E camera |
