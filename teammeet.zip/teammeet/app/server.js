// TeamMeet — app server
// - Issues LiveKit access tokens (24h TTL → no meeting time limit)
// - Starts/stops server-side recording via LiveKit Egress:
//     * one grid-layout MP4 of the whole meeting
//     * one audio file PER SPEAKER (this is how the AI notes know exactly who said what)
// - After a recording stops: transcribes each speaker (self-hosted Whisper worker),
//   merges into one speaker-labelled transcript, and asks an LLM for a summary +
//   action items per participant ("Fireflies-style" meeting notes).
// - Serves the web UI and the finished recordings/notes.

const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const {
  AccessToken,
  EgressClient,
  RoomServiceClient,
  EncodedFileOutput,
  EncodedFileType,
  DirectFileOutput,
  EgressStatus,
} = require('livekit-server-sdk');
const { summarize } = require('./summarize');

const {
  PORT = 3000,
  LIVEKIT_API_KEY = 'devkey',
  LIVEKIT_API_SECRET = 'secret',
  LIVEKIT_URL = 'ws://localhost:7880',          // URL the BROWSER uses (wss://rtc.example.com in prod)
  LIVEKIT_HOST = 'http://localhost:7880',       // URL this server uses for admin API calls
  TEAM_PASSCODE = '',                           // optional shared passcode; empty = open
  RECORDINGS_DIR = path.join(__dirname, '..', 'recordings'),
  EGRESS_OUTPUT_DIR = '/out',                   // same folder as RECORDINGS_DIR, as seen INSIDE the egress container
  TOKEN_TTL = '24h',
  WORKER_URL = 'http://localhost:8000',         // transcription worker (faster-whisper)
  AI_NOTES = 'on',                              // 'off' disables transcription + summaries
} = process.env;

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const egress = new EgressClient(LIVEKIT_HOST, LIVEKIT_API_KEY, LIVEKIT_API_SECRET);
const rooms = new RoomServiceClient(LIVEKIT_HOST, LIVEKIT_API_KEY, LIVEKIT_API_SECRET);

const cleanRoom = (r) => String(r || '').trim().toLowerCase().replace(/[^a-z0-9-_]/g, '-').slice(0, 64);
const cleanName = (n) => String(n || '').trim().slice(0, 48);
const safeId = (s) => String(s || '').replace(/[^a-zA-Z0-9-_]/g, '_').slice(0, 80);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const nsToMs = (ns) => (ns ? Number(BigInt(ns) / 1000000n) : 0);
const MIC = 2; // TrackSource.MICROPHONE in the LiveKit protocol

function checkPasscode(req, res) {
  if (!TEAM_PASSCODE) return true;
  const given = req.get('x-team-passcode') || req.body?.passcode || req.query.p || '';
  const a = Buffer.from(String(given));
  const b = Buffer.from(TEAM_PASSCODE);
  if (a.length === b.length && crypto.timingSafeEqual(a, b)) return true;
  res.status(401).json({ error: 'Wrong team passcode' });
  return false;
}

// ---------------------------------------------------------------------------
// Sessions: one folder per recording under RECORDINGS_DIR/<sessionId>/
//   session.json      status + metadata
//   meeting.mp4       grid recording (written by egress)
//   audio/*.ogg       one file per speaker track (written by egress)
//   transcript.json   merged, speaker-labelled transcript
//   notes.json/.md    AI summary + action items
// ---------------------------------------------------------------------------
const active = new Map(); // room -> session (while recording)

const sessionDir = (id) => path.join(RECORDINGS_DIR, safeId(id));
function saveSession(s) {
  fs.mkdirSync(sessionDir(s.id), { recursive: true });
  fs.writeFileSync(path.join(sessionDir(s.id), 'session.json'), JSON.stringify(s, null, 2));
}
function loadSession(id) {
  try { return JSON.parse(fs.readFileSync(path.join(sessionDir(id), 'session.json'), 'utf8')); } catch { return null; }
}

// Start an audio-only track egress for every microphone not yet being captured.
async function captureNewSpeakers(s) {
  const participants = await rooms.listParticipants(s.room);
  for (const p of participants) {
    for (const t of p.tracks || []) {
      if (t.source !== MIC || s.tracks.some((x) => x.trackSid === t.sid)) continue;
      const file = `audio/${safeId(p.identity)}__${t.sid}.ogg`;
      // reserve the slot before awaiting so the poller never double-starts
      const entry = { trackSid: t.sid, identity: p.identity, name: p.name || p.identity, file, egressId: null };
      s.tracks.push(entry);
      try {
        const info = await egress.startTrackEgress(
          s.room,
          new DirectFileOutput({ filepath: `${EGRESS_OUTPUT_DIR}/${s.id}/${file}` }),
          t.sid
        );
        entry.egressId = info.egressId;
      } catch (e) {
        entry.error = e.message;
        console.warn(`[rec] could not capture ${p.identity}: ${e.message}`);
      }
      saveSession(s);
    }
  }
}

async function startSession(room, startedBy) {
  if (active.has(room)) return active.get(room);
  const id = `${room}_${new Date().toISOString().replace(/[:.]/g, '-')}`;
  fs.mkdirSync(path.join(sessionDir(id), 'audio'), { recursive: true });
  fs.chmodSync(sessionDir(id), 0o777);
  fs.chmodSync(path.join(sessionDir(id), 'audio'), 0o777);

  const info = await egress.startRoomCompositeEgress(
    room,
    new EncodedFileOutput({ fileType: EncodedFileType.MP4, filepath: `${EGRESS_OUTPUT_DIR}/${id}/meeting.mp4` }),
    { layout: 'grid' }
  );
  const s = {
    id, room, startedBy, status: 'recording',
    createdAt: new Date().toISOString(),
    compositeEgressId: info.egressId,
    tracks: [],
  };
  active.set(room, s);
  saveSession(s);

  if (AI_NOTES !== 'off') {
    await captureNewSpeakers(s).catch((e) => console.warn('[rec]', e.message));
    // people who join (or re-join) while recording get captured too
    s._poll = setInterval(() => captureNewSpeakers(s).catch(() => {}), 5000);
  }
  return s;
}

async function stopSession(room) {
  const s = active.get(room);
  if (!s) return null;
  clearInterval(s._poll);
  delete s._poll;
  active.delete(room);
  const ids = [s.compositeEgressId, ...s.tracks.map((t) => t.egressId)].filter(Boolean);
  await Promise.all(ids.map((id) => egress.stopEgress(id).catch(() => {})));
  s.status = 'processing';
  s.stoppedAt = new Date().toISOString();
  saveSession(s);
  processSession(s.id).catch((e) => console.error('[notes]', e));
  return s;
}

// Wait for egress to finish writing, then transcribe + summarize.
async function processSession(id) {
  const s = loadSession(id);
  if (!s) return;
  const set = (patch) => { Object.assign(s, patch); saveSession(s); };
  try {
    // 1) wait for all egress jobs to finish (up to ~30 min for very long meetings)
    const ids = [s.compositeEgressId, ...s.tracks.map((t) => t.egressId)].filter(Boolean);
    const done = [EgressStatus.EGRESS_COMPLETE, EgressStatus.EGRESS_FAILED, EgressStatus.EGRESS_ABORTED, EgressStatus.EGRESS_LIMIT_REACHED];
    let infos = [];
    for (let i = 0; ids.length && i < 360; i++) {
      infos = (await Promise.all(ids.map((eid) => egress.listEgress({ egressId: eid }).catch(() => [])))).flat();
      if (infos.length && infos.every((x) => done.includes(x.status))) break;
      if (!infos.length && i >= 24) break; // egress unreachable for 2 min → use whatever files exist
      await sleep(5000);
    }
    const byId = Object.fromEntries(infos.map((x) => [x.egressId, x]));
    const meetingStart = nsToMs(byId[s.compositeEgressId]?.startedAt) || Date.parse(s.createdAt);
    s.tracks.forEach((t) => {
      const info = byId[t.egressId];
      t.startedAtMs = nsToMs(info?.startedAt) || meetingStart;
      t.offsetSec = Math.max(0, (t.startedAtMs - meetingStart) / 1000);
    });
    s.hasVideo = fs.existsSync(path.join(sessionDir(id), 'meeting.mp4'));
    s.participants = [...new Set(s.tracks.map((t) => t.name))];

    if (AI_NOTES === 'off' || !s.tracks.length) return set({ status: 'ready' });

    // 2) transcribe each speaker's audio separately → speaker labels are exact
    set({ status: 'transcribing' });
    const lines = [];
    for (const t of s.tracks) {
      const abs = path.join(sessionDir(id), t.file);
      if (!fs.existsSync(abs) || fs.statSync(abs).size < 2000) continue;
      const r = await fetch(`${WORKER_URL}/transcribe`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ path: `${safeId(id)}/${t.file}` }),
      });
      if (!r.ok) throw new Error(`Transcription worker error: ${r.status} ${await r.text()}`);
      const { segments } = await r.json();
      for (const seg of segments) {
        const text = seg.text.trim();
        if (text) lines.push({ speaker: t.name, start: seg.start + t.offsetSec, end: seg.end + t.offsetSec, text });
      }
    }
    lines.sort((a, b) => a.start - b.start);
    fs.writeFileSync(path.join(sessionDir(id), 'transcript.json'), JSON.stringify(lines, null, 2));

    // 3) AI summary + action items per participant
    set({ status: 'summarizing' });
    const notes = await summarize(lines, { room: s.room, date: s.createdAt, participants: s.participants });
    fs.writeFileSync(path.join(sessionDir(id), 'notes.json'), JSON.stringify(notes, null, 2));
    fs.writeFileSync(path.join(sessionDir(id), 'notes.md'), notesToMarkdown(s, notes));
    set({ status: 'ready' });
  } catch (e) {
    console.error(`[notes] ${id}:`, e);
    set({ status: 'error', error: e.message });
  }
}

function notesToMarkdown(s, n) {
  const out = [`# Meeting notes — ${s.room}`, `${new Date(s.createdAt).toLocaleString()} · ${s.participants.join(', ')}`, '', '## Summary', n.summary || '', ''];
  if (n.decisions?.length) out.push('## Decisions', ...n.decisions.map((d) => `- ${d}`), '');
  if (n.action_items?.length) {
    out.push('## Action items');
    for (const p of n.action_items) {
      out.push(`### ${p.owner}`, ...p.items.map((i) => `- [ ] ${i.task}${i.due ? ` _(due: ${i.due})_` : ''}`), '');
    }
  }
  if (n.topics?.length) {
    out.push('## Topics');
    for (const t of n.topics) out.push(`### ${t.title}`, t.notes || '', '');
  }
  if (n.open_questions?.length) out.push('## Open questions', ...n.open_questions.map((q) => `- ${q}`), '');
  return out.join('\n');
}

// ---------------------------------------------------------------------------
// HTTP API
// ---------------------------------------------------------------------------
app.get('/api/config', (_req, res) => {
  res.json({ livekitUrl: LIVEKIT_URL, passcodeRequired: Boolean(TEAM_PASSCODE), aiNotes: AI_NOTES !== 'off' });
});

app.post('/api/token', async (req, res) => {
  if (!checkPasscode(req, res)) return;
  const room = cleanRoom(req.body.room);
  const name = cleanName(req.body.name);
  if (!room || !name) return res.status(400).json({ error: 'room and name are required' });
  const identity = `${name.replace(/\s+/g, '_')}-${crypto.randomBytes(3).toString('hex')}`;
  const at = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, { identity, name, ttl: TOKEN_TTL });
  at.addGrant({ room, roomJoin: true, canPublish: true, canSubscribe: true, canPublishData: true });
  res.json({ token: await at.toJwt(), url: LIVEKIT_URL, room, identity });
});

app.get('/api/recording/status', (req, res) => {
  const s = active.get(cleanRoom(req.query.room));
  res.json({ recording: Boolean(s), sessionId: s?.id || null, since: s?.createdAt || null });
});

app.post('/api/recording/start', async (req, res) => {
  if (!checkPasscode(req, res)) return;
  try {
    const s = await startSession(cleanRoom(req.body.room), cleanName(req.body.name));
    res.json({ sessionId: s.id });
  } catch (e) {
    res.status(500).json({ error: `Could not start recording: ${e.message}. Is the egress service running?` });
  }
});

app.post('/api/recording/stop', async (req, res) => {
  if (!checkPasscode(req, res)) return;
  const s = await stopSession(cleanRoom(req.body.room));
  res.json({ ok: true, sessionId: s?.id || null });
});

app.get('/api/sessions', (req, res) => {
  if (!checkPasscode(req, res)) return;
  fs.mkdirSync(RECORDINGS_DIR, { recursive: true });
  const list = fs.readdirSync(RECORDINGS_DIR)
    .map((d) => loadSession(d))
    .filter(Boolean)
    .filter((s) => !req.query.room || s.room === cleanRoom(req.query.room))
    .map(({ id, room, status, createdAt, stoppedAt, participants, error }) => ({ id, room, status, createdAt, stoppedAt, participants, error }))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  res.json(list);
});

app.get('/api/sessions/:id', (req, res) => {
  if (!checkPasscode(req, res)) return;
  const s = loadSession(req.params.id);
  if (!s) return res.status(404).json({ error: 'Not found' });
  const read = (f) => { try { return JSON.parse(fs.readFileSync(path.join(sessionDir(s.id), f), 'utf8')); } catch { return null; } };
  res.json({ session: s, transcript: read('transcript.json'), notes: read('notes.json') });
});

// Re-run transcription/summary (e.g. after switching to a better LLM)
app.post('/api/sessions/:id/reprocess', (req, res) => {
  if (!checkPasscode(req, res)) return;
  const s = loadSession(req.params.id);
  if (!s) return res.status(404).json({ error: 'Not found' });
  if (['transcribing', 'summarizing', 'recording'].includes(s.status)) return res.status(409).json({ error: 'Already in progress' });
  s.status = 'processing'; delete s.error; saveSession(s);
  processSession(s.id).catch(() => {});
  res.json({ ok: true });
});

// Download/stream recording files: /files/<sessionId>/meeting.mp4, notes.md, transcript.json …
app.get('/files/:id/:file', (req, res) => {
  if (!checkPasscode(req, res)) return;
  const allowed = ['meeting.mp4', 'notes.md', 'notes.json', 'transcript.json'];
  if (!allowed.includes(req.params.file)) return res.status(404).end();
  const f = path.join(sessionDir(req.params.id), req.params.file);
  if (!fs.existsSync(f)) return res.status(404).end();
  if (req.query.download) return res.download(f, `${safeId(req.params.id)}_${req.params.file}`);
  res.sendFile(f);
});

app.get('/healthz', (_req, res) => res.send('ok'));
app.get('/notes/:id', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'notes.html')));
// Any /some-room path loads the app (so links like https://meet.example.com/standup work)
app.get(/^\/[a-zA-Z0-9-_]+$/, (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// On restart: finish any sessions that were mid-processing; mark interrupted recordings
fs.mkdirSync(RECORDINGS_DIR, { recursive: true });
for (const d of fs.readdirSync(RECORDINGS_DIR)) {
  const s = loadSession(d);
  if (!s) continue;
  if (s.status === 'recording') {
    // the app restarted mid-recording: stop the recorder jobs so the files get finalised
    [s.compositeEgressId, ...s.tracks.map((t) => t.egressId)].filter(Boolean).forEach((id) => egress.stopEgress(id).catch(() => {}));
    s.status = 'processing'; s.note = 'App restarted during recording; recording was stopped'; saveSession(s);
  }
  if (['processing', 'transcribing', 'summarizing'].includes(s.status)) processSession(s.id).catch(() => {});
}

app.listen(PORT, () => console.log(`TeamMeet app listening on :${PORT} (LiveKit: ${LIVEKIT_URL})`));
