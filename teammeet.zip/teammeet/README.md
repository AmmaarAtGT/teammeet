# TeamMeet

Self-hosted, always-on video meetings for your team — a free, open-source alternative to Google Meet / Jitsi with **no time limits**, **no per-seat fees**, built-in **meeting recording**, **screen recording**, and **AI meeting notes** (Fireflies-style summary + action items per person, with exact speaker names).

Built on [LiveKit](https://livekit.io) (Apache-2.0 open-source WebRTC media server), Node.js, faster-whisper (open-source speech-to-text) and any OpenAI-compatible LLM (default: free local Ollama).

---

## Features

| Area | What you get |
|---|---|
| Meetings | Unlimited duration (24h tokens, rooms stay open while anyone is in them), no participant cap in software, permanent room links (`https://meet.yourco.com/standup`) |
| Controls | Mic mute/unmute, camera on/off, screen share (with tab audio), raise hand, chat, people list, pin a tile, copy invite link, device picker, keyboard shortcuts |
| Speaker identity | Green border + green name tag on whoever is talking, "🎙 who's speaking" in the top bar, network-quality dot per person |
| Background | Each person chooses their own: none, light / medium / strong blur, 8 neutral colors or any custom color. Saved per device. Works in the lobby preview too |
| Meeting recording | One click records the whole meeting on the server as an MP4 grid video; everyone sees a red **REC** badge |
| Screen recording | Records your screen + everyone's audio straight to your own computer (no server needed) |
| AI notes | After a recording: speaker-labelled transcript, summary, decisions, detailed topic notes, open questions, and **action items grouped by person** with due dates. Click any transcript line to jump the video there. Download as Markdown |
| Privacy | Everything runs on your server. Transcription and (by default) the LLM are local — no meeting audio leaves your infrastructure |
| Access | Optional shared team passcode |

## Screens

`app/public/index.html` (lobby + meeting) and `app/public/notes.html` (meeting notes). See [docs/USER_GUIDE.md](docs/USER_GUIDE.md) for every button.

## Quick start (production, ~20 minutes)

You need: a Linux server (Ubuntu 22.04/24.04, 8 vCPU / 16 GB RAM recommended — see [sizing](docs/DEPLOYMENT.md#1-server-sizing)), Docker, and two DNS names.

```bash
git clone <your-repo> teammeet && cd teammeet
./scripts/setup.sh meet.yourco.com rtc.yourco.com      # creates .env + configs + secret keys
# point both DNS A-records at the server; open firewall ports (see output)
docker compose --profile ollama up -d --build
docker compose exec ollama ollama pull llama3.1:8b      # one-time AI model download
./scripts/healthcheck.sh                                # all checks should pass
```

Open `https://meet.yourco.com`, enter your name, join. Share `https://meet.yourco.com/<room>` with the team.

Full step-by-step: **[docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)**.

## Local development (5 minutes)

```bash
# 1. LiveKit media server in dev mode (keys: devkey / secret)
curl -sSL https://get.livekit.io | bash        # or: brew install livekit
livekit-server --dev

# 2. App (another terminal)
cd app && npm install && npm run build && npm run dev
# open http://localhost:3000 in two browser windows
```

Recording and AI notes need the Docker stack — see [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md#3-running-the-full-stack-locally).

## Documentation

| Doc | For | Contents |
|---|---|---|
| [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) | DevOps | Server sizing, DNS, firewall, install, upgrade, backup, GPU, scaling |
| [docs/CONFIGURATION.md](docs/CONFIGURATION.md) | DevOps / Dev | Every environment variable and config file, with defaults |
| [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md) | Developers | Architecture, file map, how each feature works, API reference, how to extend |
| [docs/TESTING.md](docs/TESTING.md) | Dev / QA | Automated tests, end-to-end tests, full manual QA checklist, load testing |
| [docs/USER_GUIDE.md](docs/USER_GUIDE.md) | Everyone | What every button does, shortcuts, recording etiquette |
| [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) | Everyone | Symptom → cause → fix |

## Repository layout

```
teammeet/
├── README.md
├── docker-compose.yml          production stack (host networking, Linux)
├── docker-compose.local.yml    override for testing the full stack on one machine
├── .env.example                all settings (copied to .env by setup.sh)
├── config/
│   ├── livekit.yaml.template   media server config  → livekit.yaml
│   ├── egress.yaml.template    recorder config      → egress.yaml
│   └── Caddyfile               automatic HTTPS reverse proxy
├── scripts/
│   ├── setup.sh                one-time setup, generates keys
│   └── healthcheck.sh          checks every service
├── app/                        Node.js web app + API
│   ├── server.js               tokens, recording control, AI-notes pipeline, file serving
│   ├── summarize.js            LLM summary + action items (map-reduce for long meetings)
│   ├── build/                  bundles browser libraries into public/vendor
│   ├── public/                 UI: index.html, app.js, style.css, notes.html
│   └── tests/                  automated tests (npm test)
├── worker/                     Python speech-to-text service (faster-whisper)
├── recordings/                 meeting videos, audio, transcripts, notes (git-ignored)
└── docs/
```

## License

MIT for this project. LiveKit server/egress: Apache-2.0. faster-whisper: MIT. Llama models: Meta Llama license (choose any other model if preferred).
